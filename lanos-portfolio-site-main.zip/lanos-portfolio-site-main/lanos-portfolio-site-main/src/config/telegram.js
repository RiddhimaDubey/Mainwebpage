// Telegram Bot Configuration
const BOT_TOKEN = '7753450891:AAGbWkWF2ytud5mPz2boxwRY2f51GJqN6ys';
const CHAT_ID = '6067712594';

export const TELEGRAM_CONFIG = {
  BOT_TOKEN,
  CHAT_ID
}; 